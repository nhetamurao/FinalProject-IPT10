<?php
namespace App\Controllers;

use App\Models\Product;

class ProductController extends BaseController
{
    public function __construct()
    {
        $this->startSession(); // Ensures session is started
    }

    public function manageProducts()
    {
        $productModel = new Product();
        $products = $productModel->getAllProducts();

        $data = [
            'products' => $products        
        ];
        // Now uses the renderPage method from BaseController
        echo $this->renderPage('managed-products', $data);
    }

    public function showAddNewProducts()
    {
        $productModel = new Product();
        $products = $productModel->getAllProducts();

        $data = [
            'products' => $products        
        ];
        // Now uses the renderPage method from BaseController
        echo $this->renderPage('add-product', $data);
    }

    


    public function manageProduct()
    {
        $productModel = new Product();
        $products = $productModel->getAllProducts();

        $data = [
            'products' => $products        
        ];
        // Render the page using renderPage method from BaseController
        echo $this->renderPage('managed-products', $data);
    }

    // Show the form for adding a new product
    public function showAddNewProduct()
    {
        $categoryModel = new Category();
        $categories = $categoryModel->getAllCategories();

        $data = [
            'categories' => $categories        
        ];
        // Render the page using renderPage method from BaseController
        echo $this->renderPage('add-product', $data);
    }

    // Add a new product
    public function addProduct()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_name'])) {
            $product_name = $_POST['product_name'];
            $category_id = $_POST['category_id'];
            $quantity = $_POST['quantity'];
            $buy_price = $_POST['buy_price'];
            $sale_price = $_POST['sale_price'];
            $media_file_name = isset($_POST['media_file_name']) ? $_POST['media_file_name'] : null;  // Assuming it's an uploaded file name

            // Validate input
            if (empty($product_name) || empty($category_id) || empty($quantity) || empty($buy_price) || empty($sale_price)) {
                $_SESSION['msg'] = 'All fields are required.';
                $_SESSION['msg_type'] = 'danger';  // Set message type to error
            } else {
                $productModel = new Product();
                $result = $productModel->save($product_name, $category_id, $quantity, $buy_price, $sale_price, $media_file_name);

                if ($result > 0) {
                    $_SESSION['msg'] = 'Product added successfully.';
                    $_SESSION['msg_type'] = 'success';  // Set message type to success
                } else {
                    $_SESSION['msg'] = 'Failed to add product.';
                    $_SESSION['msg_type'] = 'danger';  // Set message type to error
                }
            }
        }
        // Redirect back to the manage products page to display the message
        $this->redirect('/managed-products');
    }

    // Edit a product
    public function editProduct()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

        if ($id <= 0) {
            $_SESSION['msg'] = 'Invalid product ID.';
            $_SESSION['msg_type'] = 'danger';  // Set message type to error
            $this->redirect('/managed-products');
        }

        $productModel = new Product();
        $product = $productModel->getProductById($id);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_name'])) {
            $product_name = $_POST['product_name'];
            $category_id = $_POST['category_id'];
            $quantity = $_POST['quantity'];
            $buy_price = $_POST['buy_price'];
            $sale_price = $_POST['sale_price'];
            $media_file_name = isset($_POST['media_file_name']) ? $_POST['media_file_name'] : null;  // Assuming it's an uploaded file name

            // Validate input
            if (empty($product_name) || empty($category_id) || empty($quantity) || empty($buy_price) || empty($sale_price)) {
                $_SESSION['msg'] = 'All fields are required.';
                $_SESSION['msg_type'] = 'danger';  // Set message type to error
                $this->redirect('/edit-product?id=' . $id);
            }

            $result = $productModel->update($id, $product_name, $category_id, $quantity, $buy_price, $sale_price, $media_file_name);

            if ($result > 0) {
                $_SESSION['msg'] = 'Product updated successfully.';
                $_SESSION['msg_type'] = 'success';  // Set message type to success
            } else {
                $_SESSION['msg'] = 'Failed to update product.';
                $_SESSION['msg_type'] = 'danger';  // Set message type to error
            }

            $this->redirect('/managed-products');
        }

        $data = [
            'product' => $product
        ];
        echo $this->renderPage('edit-product', $data);
    }

    // Delete a product
    public function deleteProduct()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

        if ($id <= 0) {
            $_SESSION['msg'] = 'Invalid product ID.';
            $_SESSION['msg_type'] = 'danger';  // Set message type to error
            $this->redirect('/managed-products');
            return;
        }

        $productModel = new Product();
        $result = $productModel->delete($id);

        if ($result > 0) {
            $_SESSION['msg'] = 'Product deleted successfully.';
            $_SESSION['msg_type'] = 'success';  // Set message type to success
        } else {
            $_SESSION['msg'] = 'Failed to delete product.';
            $_SESSION['msg_type'] = 'danger';  // Set message type to error
        }

        $this->redirect('/managed-products');
    }

    // Redirect to a specific URL
    public function redirect($url)
    {
        header("Location: " . $url);
        exit;
    }
}