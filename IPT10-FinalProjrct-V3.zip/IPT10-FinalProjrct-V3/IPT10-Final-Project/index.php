<?php

require "vendor/autoload.php";
require "init.php";

// Database connection object (from init.php (DatabaseConnection))
global $conn;

try {



    // Create Router instance
    $router = new \Bramus\Router\Router();

    // Define routes
    $router->get('/login-form', '\App\Controllers\LoginController@showLoginForm');
    $router->post('/login', '\App\Controllers\LoginController@login');
    $router->get('/logout', '\App\Controllers\LoginController@logout');


    $router->get('/', '\App\Controllers\PageController@dashboard');
    $router->get('/documentation', '\App\Controllers\PageController@documentation');


    $router->get('/manage-products', '\App\Controllers\ProductController@manageProducts');
    $router->get('/add-product', '\App\Controllers\ProductController@showAddNewProducts');
    $router->get('/edit-product', '\App\Controllers\ProductController@editProduct');
    $router->post('/edit-product', '\App\Controllers\ProductController@updateProduct');
    $router->get('/delete-product', '\App\Controllers\ProductController@deleteProduct');


    // Define Categories routes
    $router->get('/categories', '\App\Controllers\CategoryController@showCategories');
    $router->post('/add-category', '\App\Controllers\CategoryController@addCategory');
    $router->get('/edit-category', '\App\Controllers\CategoryController@editCategory');  // For GET requests
    $router->post('/edit-category', '\App\Controllers\CategoryController@editCategory'); // For POST requests
    $router->get('/delete-category', '\App\Controllers\CategoryController@deleteCategory'); // For DELETE requests
    
    


    // Run it!
    $router->run();

} catch (Exception $e) {

    echo json_encode([
        'error' => $e->getMessage()
    ]);

}
